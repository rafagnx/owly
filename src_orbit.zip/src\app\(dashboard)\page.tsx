import { Header } from "@/components/layout/header";
import { StatCard } from "@/components/ui/stat-card";
import { OnboardingChecklist } from "@/components/ui/onboarding-checklist";
import { prisma } from "@/lib/prisma";
import {
  MessageSquare,
  Ticket,
  Phone,
  Mail,
  MessageCircle,
  CheckCircle,
  Clock,
} from "lucide-react";
import { formatRelativeTime, getChannelLabel, getStatusColor } from "@/lib/utils";

async function getStats() {
  const [
    totalConversations,
    activeConversations,
    totalTickets,
    openTickets,
    totalMessages,
    recentConversations,
  ] = await Promise.all([
    prisma.conversation.count(),
    prisma.conversation.count({ where: { status: "active" } }),
    prisma.ticket.count(),
    prisma.ticket.count({ where: { status: "open" } }),
    prisma.message.count(),
    prisma.conversation.findMany({
      take: 10,
      orderBy: { updatedAt: "desc" },
      include: {
        messages: { take: 1, orderBy: { createdAt: "desc" } },
        _count: { select: { messages: true } },
      },
    }),
  ]);

  const resolvedConversations = await prisma.conversation.count({
    where: { status: "resolved" },
  });

  const resolutionRate =
    totalConversations > 0
      ? Math.round((resolvedConversations / totalConversations) * 100)
      : 0;

  return {
    totalConversations,
    activeConversations,
    totalTickets,
    openTickets,
    totalMessages,
    resolutionRate,
    recentConversations,
  };
}

const channelIcons: Record<string, React.ElementType> = {
  whatsapp: MessageCircle,
  email: Mail,
  phone: Phone,
};

export default async function DashboardPage() {
  const stats = await getStats();
  
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";

  return (
    <>
      <Header
        title="Painel de Controle"
        description="Visão geral da sua atividade de suporte"
      />
      <div className="flex-1 overflow-auto p-6 space-y-6 bg-owly-bg">
        <div className="flex flex-col gap-1">
          <h2 className="text-3xl font-black text-white tracking-tighter">
            {greeting}, Rafael
          </h2>
          <p className="text-owly-text-light text-sm font-medium">Aqui está o que está acontecendo no Owly hoje.</p>
        </div>

        <OnboardingChecklist />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Total de Conversas"
            value={stats.totalConversations}
            icon={MessageSquare}
          />
          <StatCard
            title="Ativas Agora"
            value={stats.activeConversations}
            icon={Clock}
            iconColor="bg-green-500/10 text-green-500"
          />
          <StatCard
            title="Chamados Abertos"
            value={stats.openTickets}
            icon={Ticket}
            iconColor="bg-owly-primary/10 text-owly-primary"
          />
          <StatCard
            title="Taxa de Resolução"
            value={`${stats.resolutionRate}%`}
            icon={CheckCircle}
            iconColor="bg-blue-500/10 text-blue-500"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-owly-surface rounded-xl border border-owly-border overflow-hidden">
            <div className="px-5 py-4 border-b border-owly-border bg-white/[0.02]">
              <h3 className="font-bold text-owly-text uppercase tracking-widest text-xs">
                Conversas Recentes
              </h3>
            </div>
            <div className="divide-y divide-owly-border">
              {stats.recentConversations.length === 0 ? (
                <div className="px-5 py-12 text-center text-owly-text-light">
                  <MessageSquare className="h-10 w-10 mx-auto mb-3 opacity-20" />
                  <p className="font-semibold">Nenhuma conversa ainda</p>
                  <p className="text-sm mt-1 opacity-70">
                    As conversas aparecerão aqui quando os clientes entrarem em contato
                  </p>
                </div>
              ) : (
                stats.recentConversations.map((conv) => {
                  const ChannelIcon =
                    channelIcons[conv.channel] || MessageSquare;
                  const lastMessage = conv.messages[0];
                  return (
                    <div
                      key={conv.id}
                      className="px-5 py-4 hover:bg-owly-primary/5 transition-colors cursor-pointer group"
                    >
                      <div className="flex items-start gap-4">
                        <div className="p-2.5 rounded-xl bg-owly-primary/10 text-owly-primary mt-0.5 group-hover:scale-110 transition-transform">
                          <ChannelIcon className="h-4 w-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <p className="font-bold text-sm text-owly-text truncate">
                              {conv.customerName}
                            </p>
                            <span className="text-[10px] font-mono text-owly-text-light flex-shrink-0 ml-2 uppercase">
                              {formatRelativeTime(conv.updatedAt)}
                            </span>
                          </div>
                          <p className="text-[11px] font-medium text-owly-text-light/60 mt-0.5 uppercase tracking-wider">
                            {getChannelLabel(conv.channel)} • {conv._count.messages} mensagens
                          </p>
                          {lastMessage && (
                            <p className="text-sm text-owly-text-light mt-2 truncate italic opacity-80">
                              "{lastMessage.content}"
                            </p>
                          )}
                        </div>
                        <span
                          className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider ${getStatusColor(conv.status)}`}
                        >
                          {conv.status === 'active' ? 'Ativa' : conv.status === 'resolved' ? 'Resolvida' : conv.status}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-owly-surface rounded-xl border border-owly-border overflow-hidden">
              <div className="px-5 py-4 border-b border-owly-border bg-white/[0.02]">
                <h3 className="font-bold text-owly-text uppercase tracking-widest text-xs">
                  Visão Geral dos Canais
                </h3>
              </div>
              <div className="p-5 space-y-4">
                {[
                  {
                    name: "WhatsApp",
                    icon: MessageCircle,
                    color: "text-green-500",
                  },
                  { name: "E-mail", icon: Mail, color: "text-blue-500" },
                  { name: "Telefone", icon: Phone, color: "text-purple-500" },
                ].map((channel) => (
                  <div
                    key={channel.name}
                    className="flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2.5">
                      <channel.icon
                        className={`h-4 w-4 ${channel.color}`}
                      />
                      <span className="text-sm font-semibold">
                        {channel.name}
                      </span>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-md bg-owly-primary/10 text-owly-primary font-bold uppercase tracking-tighter">
                      Conectado
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-owly-surface rounded-xl border border-owly-border overflow-hidden">
              <div className="px-5 py-4 border-b border-owly-border bg-white/[0.02]">
                <h3 className="font-bold text-owly-text uppercase tracking-widest text-xs">Estatísticas Rápidas</h3>
              </div>
              <div className="p-5 space-y-4">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-owly-text-light font-medium">Total de Mensagens</span>
                  <span className="font-mono font-bold text-white bg-white/5 px-2 py-0.5 rounded">{stats.totalMessages}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-owly-text-light font-medium">Total de Chamados</span>
                  <span className="font-mono font-bold text-white bg-white/5 px-2 py-0.5 rounded">{stats.totalTickets}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-owly-text-light font-medium">
                    Taxa Média de Resolução
                  </span>
                  <span className="font-mono font-bold text-owly-success bg-owly-success/10 px-2 py-0.5 rounded">{stats.resolutionRate}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
