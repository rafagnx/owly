"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  BookOpen,
  Users,
  Contact,
  MessageSquare,
  Settings,
  Radio,
  Ticket,
  BarChart3,
  ScrollText,
  Timer,
  Zap,
  Workflow,
  Clock,
  Shield,
  FileCode,
  Webhook,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { useState } from "react";

interface NavSection {
  title?: string;
  items: { name: string; href: string; icon: React.ElementType }[];
}

const sections: NavSection[] = [
  {
    items: [
      { name: "Painel", href: "/", icon: LayoutDashboard },
      { name: "Conversas", href: "/conversations", icon: MessageSquare },
      { name: "Clientes", href: "/customers", icon: Contact },
      { name: "Chamados", href: "/tickets", icon: Ticket },
    ],
  },
  {
    title: "Conhecimento",
    items: [
      { name: "Base de Dados", href: "/knowledge", icon: BookOpen },
      { name: "Respostas Rápidas", href: "/canned-responses", icon: Zap },
      { name: "Automação", href: "/automation", icon: Workflow },
      { name: "Horários", href: "/business-hours", icon: Clock },
    ],
  },
  {
    title: "Equipe",
    items: [
      { name: "Membros", href: "/team", icon: Users },
      { name: "Regras SLA", href: "/sla", icon: Timer },
    ],
  },
  {
    title: "Canais",
    items: [
      { name: "Canais", href: "/channels", icon: Radio },
      { name: "Webhooks", href: "/webhooks", icon: Webhook },
    ],
  },
  {
    title: "Relatórios",
    items: [
      { name: "Analíticos", href: "/analytics", icon: BarChart3 },
      { name: "Log de Atividade", href: "/activity", icon: ScrollText },
    ],
  },
  {
    title: "Sistema",
    items: [
      { name: "Administração", href: "/admin", icon: Shield },
      { name: "Docs da API", href: "/api-docs", icon: FileCode },
      { name: "Configurações", href: "/settings", icon: Settings },
    ],
  },
];

export function Sidebar() {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside
      className={cn(
        "flex flex-col bg-owly-sidebar text-white transition-all duration-300 border-r border-white/5",
        collapsed ? "w-16" : "w-60"
      )}
    >
      <div className="flex items-center gap-3 px-4 py-6 border-b border-white/5">
        <div className="bg-owly-primary p-1.5 rounded-lg">
          <Image
            src="/owly.png"
            alt="Owly"
            width={24}
            height={24}
            className="flex-shrink-0 invert"
          />
        </div>
        {!collapsed && (
          <div className="overflow-hidden">
            <h1 className="text-lg font-black tracking-tighter uppercase italic">Owly</h1>
            <p className="text-[9px] text-white/40 font-mono">SUPORTE IA</p>
          </div>
        )}
      </div>

      <nav className="flex-1 px-3 py-4 overflow-y-auto space-y-4">
        {sections.map((section, si) => (
          <div key={si}>
            {section.title && !collapsed && (
              <p className="px-3 mb-2 text-[10px] uppercase tracking-[0.2em] text-white/30 font-bold">
                {section.title}
              </p>
            )}
            <div className="space-y-1">
              {section.items.map((item) => {
                const isActive =
                  pathname === item.href ||
                  (item.href !== "/" && pathname.startsWith(item.href));

                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      "group flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] font-semibold transition-all duration-200 relative overflow-hidden",
                      isActive
                        ? "bg-owly-sidebar-active text-white"
                        : "text-white/50 hover:bg-owly-sidebar-hover hover:text-white"
                    )}
                    title={collapsed ? item.name : undefined}
                  >
                    {isActive && (
                      <div className="absolute left-0 top-1.5 bottom-1.5 w-1 bg-owly-primary rounded-r-full" />
                    )}
                    <item.icon className={cn("h-4 w-4 flex-shrink-0 transition-transform group-hover:scale-110", isActive ? "text-owly-primary" : "")} />
                    {!collapsed && <span>{item.name}</span>}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="px-2 py-2 border-t border-white/10">
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center justify-center w-full py-1.5 rounded-md text-white/40 hover:text-white hover:bg-owly-sidebar-hover transition-colors"
        >
          {collapsed ? (
            <ChevronRight className="h-4 w-4" />
          ) : (
            <ChevronLeft className="h-4 w-4" />
          )}
        </button>
      </div>
    </aside>
  );
}
