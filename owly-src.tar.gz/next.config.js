/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  experimental: {
    serverComponentsExternalPackages: [
      "whatsapp-web.js", 
      "puppeteer", 
      "@prisma/client",
      "prisma"
    ]
  },
};

module.exports = nextConfig;
