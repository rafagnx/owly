import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  change?: string;
  changeType?: "positive" | "negative" | "neutral";
  icon?: LucideIcon;
}

export function StatCard({
  title,
  value,
  change,
  changeType = "neutral",
  icon: Icon,
}: StatCardProps) {
  return (
    <div className="bg-[#18181B] border border-[#27272A] p-6 rounded-2xl space-y-3 hover:border-[#3F3F46] transition-all group overflow-hidden relative">
      <div className="flex items-start justify-between">
        <div className="flex flex-col gap-1">
          <span className="text-[11px] font-bold text-[#A1A1AA] uppercase tracking-wider font-mono">
            {title}
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-4xl font-extrabold text-white tracking-tight font-mono">
              {value}
            </span>
          </div>
        </div>
        {Icon && (
          <div className="p-2 rounded-xl bg-[#27272A] text-white/50 group-hover:text-owly-primary transition-colors">
            <Icon className="h-5 w-5" />
          </div>
        )}
      </div>
      
      {change && (
        <div className="flex items-center gap-2">
          <span className={cn(
            "text-xs font-bold font-mono",
            changeType === "positive" ? "text-[#22C55E]" : 
            changeType === "negative" ? "text-[#EF4444]" : "text-[#A1A1AA]"
          )}>
            {changeType === "positive" ? "+" : ""}{change}
          </span>
          <span className="text-[11px] text-[#52525B] font-medium tracking-tight">
            vs último mês
          </span>
        </div>
      )}
      
      {/* Subtle decoration */}
      <div className="absolute right-[-10px] bottom-[-10px] opacity-10 group-hover:opacity-20 transition-opacity">
         <div className="w-24 h-24 bg-white/10 rounded-full blur-3xl" />
      </div>
    </div>
  );
}
