"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    async function checkAuth() {
      try {
        const res = await fetch("/api/auth");
        const data = await res.json();
        if (data.setupRequired) {
          router.replace("/setup");
          return;
        }
        if (data.authenticated) {
          router.replace("/");
          return;
        }
      } catch {
        // Allow login page to render
      }
      setChecking(false);
    }
    checkAuth();
  }, [router]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "login", username, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Login failed. Please try again.");
        setLoading(false);
        return;
      }

      router.replace("/");
    } catch {
      setError("An unexpected error occurred. Please try again.");
      setLoading(false);
    }
  }

  if (checking) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-owly-primary border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="bg-owly-surface rounded-[8px] border border-owly-border p-10 overflow-hidden relative group">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-owly-primary to-transparent opacity-50" />
      
      <div className="flex flex-col items-center mb-10">
        <div className="p-3 bg-owly-primary/10 rounded-2xl mb-4 group-hover:scale-110 transition-transform duration-500">
          <Image
            src="/owly.png"
            alt="Owly"
            width={48}
            height={48}
            className="invert"
          />
        </div>
        <h1 className="text-3xl font-black text-white tracking-tighter uppercase italic">
          Owly Admin
        </h1>
        <p className="text-owly-text-light text-[11px] mt-1 font-mono uppercase tracking-widest opacity-60">
          Acesse sua conta para continuar
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label
            htmlFor="username"
            className="block text-[10px] font-bold text-white uppercase tracking-widest mb-2 ml-1"
          >
            Nome de usuário
          </label>
          <input
            id="username"
            type="text"
            autoComplete="username"
            required
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full rounded-md border border-owly-border bg-black/20 px-4 py-3 text-sm text-white placeholder:text-white/20 focus:outline-none focus:ring-1 focus:ring-owly-primary focus:border-owly-primary transition-all font-mono"
            placeholder="usuário"
          />
        </div>

        <div>
          <label
            htmlFor="password"
            className="block text-[10px] font-bold text-white uppercase tracking-widest mb-2 ml-1"
          >
            Senha
          </label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-md border border-owly-border bg-black/20 px-4 py-3 text-sm text-white placeholder:text-white/20 focus:outline-none focus:ring-1 focus:ring-owly-primary focus:border-owly-primary transition-all font-mono"
            placeholder="••••••••"
          />
        </div>

        {error && (
          <div className="rounded-md bg-owly-danger/10 border border-owly-danger/20 px-4 py-3 text-xs text-owly-danger font-bold uppercase tracking-tight text-center">
            {error === "Login failed. Please try again." ? "Nome de usuário ou senha incorretos" : error}
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-md bg-owly-primary px-4 py-3.5 text-xs font-black text-white uppercase tracking-[0.2em] hover:bg-owly-primary-dark hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 disabled:hover:scale-100 shadow-xl shadow-owly-primary/10"
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <span className="h-3 w-3 animate-spin rounded-full border-2 border-white border-t-transparent" />
              Entrando...
            </span>
          ) : (
            "Acessar Painel"
          )}
        </button>
      </form>
    </div>
  );
}
