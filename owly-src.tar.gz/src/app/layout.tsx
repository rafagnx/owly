export const dynamic = "force-dynamic";
import type { Metadata } from "next";
import { Providers } from "@/components/providers";
import { ThemeInit } from "@/components/theme-init";
import "./globals.css";

export const metadata: Metadata = {
  title: "Owly - AI Customer Support",
  description: "Open-source AI-powered customer support agent",
  icons: {
    icon: "/owly.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" className="h-full antialiased dark">
      <head>
        {/* Bypass Tailwind compilation problems by using direct styling */}
        <script src="https://cdn.tailwindcss.com"></script>
        <script dangerouslySetInnerHTML={{ __html: `
          tailwind.config = {
            darkMode: 'class',
            theme: {
              extend: {
                colors: {
                  owly: {
                    primary: "#f97316",
                    bg: "#09090B",
                    surface: "#18181B",
                    text: "#FFFFFF",
                    border: "#27272A",
                  },
                },
              },
            },
          }
        `}} />
      </head>
      <body className="h-full bg-[#09090B] text-white">
          <Providers>
            <ThemeInit />
            {children}
          </Providers>
      </body>
    </html>
  );
}
